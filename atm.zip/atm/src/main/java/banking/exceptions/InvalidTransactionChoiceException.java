package banking.exceptions;

public class InvalidTransactionChoiceException extends Exception {

	public InvalidTransactionChoiceException() {
		super("This is an invalid transaction choice.");
	}
	

}
