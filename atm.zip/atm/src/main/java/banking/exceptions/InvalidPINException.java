package banking.exceptions;

public class InvalidPINException extends Exception {

	public InvalidPINException() {
		super("Invalid PIN format.");
	}
	

}
